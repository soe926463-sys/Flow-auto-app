document.addEventListener("DOMContentLoaded", () => {
  const statusEl = document.getElementById("status");
  const detailsEl = document.getElementById("details");
  const btn = document.getElementById("reconnectBtn");

  function checkConnection() {
    statusEl.textContent = "Testing...";
    statusEl.className = "status-badge";

    const ws = new WebSocket("ws://127.0.0.1:28841/flow-bridge");
    ws.onopen = () => {
      statusEl.textContent = "Connected to App";
      statusEl.className = "status-badge connected";
      detailsEl.textContent = "Loopback active. Flow Auto Production app is ready to receive tasks.";
      ws.close();
    };
    ws.onerror = () => {
      statusEl.textContent = "App Not Reachable";
      statusEl.className = "status-badge disconnected";
      detailsEl.textContent = "Ensure 'Flow Auto Production' is open on your Samsung phone before running.";
    };
  }

  btn.addEventListener("click", checkConnection);
  checkConnection();
});
