// content.js - Flow Auto Production Bridge for Lemur Browser
// Runs inside https://flow.google.com/*

(function () {
  console.log("[Flow Bridge] Initializing Flow Auto Production content script...");

  let socket = null;
  let isExecuting = false;
  let currentSceneNumber = null;
  let currentIntentId = null;
  let abortRequested = false;

  const WS_URL = "ws://127.0.0.1:28841/flow-bridge";

  function connectBridge() {
    if (socket && socket.readyState === WebSocket.OPEN) return;

    try {
      socket = new WebSocket(WS_URL);

      socket.onopen = () => {
        console.log("[Flow Bridge] Connected to Flow Auto Production app on localhost:28841");
        const credits = readCreditBalance();
        socket.send(JSON.stringify({
          type: "HANDSHAKE",
          client: "Lemur Browser (Android)",
          credits: credits || "Credits Loaded"
        }));
      };

      socket.onmessage = (event) => {
        try {
          const msg = JSON.parse(event.data);
          handleAppCommand(msg);
        } catch (e) {
          console.error("[Flow Bridge] Error parsing message:", e);
        }
      };

      socket.onclose = () => {
        console.log("[Flow Bridge] Connection closed. Retrying in 3s...");
        setTimeout(connectBridge, 3000);
      };

      socket.onerror = (err) => {
        console.warn("[Flow Bridge] WebSocket error (ensure Android app is running):", err);
      };
    } catch (e) {
      console.error("[Flow Bridge] Connection error:", e);
      setTimeout(connectBridge, 3000);
    }
  }

  // Periodic credit updater
  setInterval(() => {
    if (socket && socket.readyState === WebSocket.OPEN) {
      const credits = readCreditBalance();
      if (credits) {
        socket.send(JSON.stringify({
          type: "CREDIT_UPDATE",
          credits: credits
        }));
      }
    }
  }, 10000);

  function readCreditBalance() {
    // Flow displays credits in header profile popover or header badge
    const creditSelectors = [
      '[aria-label*="credit" i]',
      '[aria-label*="balance" i]',
      '.credits-badge',
      '.credit-balance',
      'div:contains("credits")'
    ];
    for (const sel of creditSelectors) {
      const el = document.querySelector(sel);
      if (el && el.textContent) {
        return el.textContent.trim();
      }
    }
    return null;
  }

  async function handleAppCommand(msg) {
    if (msg.type === "GENERATE_IMAGE") {
      await executeImageGeneration(msg);
    } else if (msg.type === "GENERATE_VIDEO") {
      await executeVideoGeneration(msg);
    } else if (msg.type === "STOP_EXECUTION") {
      abortRequested = true;
      console.log("[Flow Bridge] Received stop command from Android app.");
    }
  }

  async function executeImageGeneration(job) {
    isExecuting = true;
    abortRequested = false;
    currentSceneNumber = job.sceneNumber;
    currentIntentId = job.intentId;

    notifyProgress(currentSceneNumber, 10, "Injecting prompt into Google Flow...");

    try {
      // 1. Locate prompt input
      const promptInput = await waitForPromptInput();
      if (!promptInput) {
        throw new Error("Could not locate Google Flow prompt input box.");
      }

      // 2. Set prompt value safely
      setInputValue(promptInput, job.prompt);
      notifyProgress(currentSceneNumber, 25, "Prompt set. Selecting model and aspect ratio...");

      // 3. Select Image mode if not already active
      await selectMode("Image");

      // 4. Select Aspect Ratio if configured
      if (job.aspectRatio) {
        await selectAspectRatio(job.aspectRatio);
      }

      // 5. Click Generate button
      notifyProgress(currentSceneNumber, 40, "Submitting generation to Flow...");
      const genButton = await findGenerateButton();
      if (!genButton) {
        throw new Error("Could not find Flow 'Generate' button.");
      }

      genButton.click();
      notifyProgress(currentSceneNumber, 50, "Generating image... waiting for completion");

      // 6. Monitor generation until completion
      const assetResult = await waitForGenerationCompletion(currentSceneNumber, "image");

      if (assetResult.isSuccess) {
        notifyCompleted(currentSceneNumber, assetResult.jobId, assetResult.assetUrl);
      } else {
        notifyFailed(currentSceneNumber, assetResult.error);
      }
    } catch (err) {
      notifyFailed(currentSceneNumber, err.message || "Failed during image execution");
    } finally {
      isExecuting = false;
    }
  }

  async function executeVideoGeneration(job) {
    isExecuting = true;
    abortRequested = false;
    currentSceneNumber = job.sceneNumber;
    currentIntentId = job.intentId;

    notifyProgress(currentSceneNumber, 10, "Setting up Video generation...");

    try {
      const promptInput = await waitForPromptInput();
      if (!promptInput) {
        throw new Error("Could not locate Google Flow prompt input box.");
      }

      // Switch to Video mode
      await selectMode("Video");
      notifyProgress(currentSceneNumber, 20, "Video mode selected. Attaching frame image...");

      // If imageBase64 is provided, attach to start frame
      if (job.imageBase64) {
        await attachStartFrameImage(job.imageBase64);
      }

      // Set prompt
      setInputValue(promptInput, job.prompt);
      notifyProgress(currentSceneNumber, 35, "Video prompt injected. Configuring settings...");

      // Set duration / settings
      if (job.duration) {
        await selectDuration(job.duration);
      }

      // Click Generate
      const genButton = await findGenerateButton();
      if (!genButton) {
        throw new Error("Could not find Flow 'Generate' button.");
      }

      genButton.click();
      notifyProgress(currentSceneNumber, 45, "Generating video... waiting for Flow rendering");

      // Monitor completion
      const assetResult = await waitForGenerationCompletion(currentSceneNumber, "video");

      if (assetResult.isSuccess) {
        notifyCompleted(currentSceneNumber, assetResult.jobId, assetResult.assetUrl);
      } else {
        notifyFailed(currentSceneNumber, assetResult.error);
      }
    } catch (err) {
      notifyFailed(currentSceneNumber, err.message || "Failed during video execution");
    } finally {
      isExecuting = false;
    }
  }

  // --- Helper DOM Automation Functions ---

  function setInputValue(el, text) {
    el.focus();
    if (el.tagName === "TEXTAREA" || el.tagName === "INPUT") {
      const nativeSetter = Object.getOwnPropertyDescriptor(
        window.HTMLTextAreaElement.prototype,
        "value"
      )?.set || Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, "value")?.set;

      if (nativeSetter) {
        nativeSetter.call(el, text);
      } else {
        el.value = text;
      }
    } else {
      // Contenteditable
      el.textContent = text;
    }

    el.dispatchEvent(new Event("input", { bubbles: true }));
    el.dispatchEvent(new Event("change", { bubbles: true }));
    el.dispatchEvent(new KeyboardEvent("keydown", { bubbles: true }));
    el.dispatchEvent(new KeyboardEvent("keyup", { bubbles: true }));
  }

  async function waitForPromptInput() {
    for (let i = 0; i < 30; i++) {
      const candidates = [
        document.querySelector('textarea[placeholder*="scene" i]'),
        document.querySelector('textarea[placeholder*="prompt" i]'),
        document.querySelector('textarea[placeholder*="describe" i]'),
        document.querySelector('div[contenteditable="true"]'),
        document.querySelector('textarea')
      ];
      for (const c of candidates) {
        if (c && c.offsetParent !== null) return c;
      }
      await sleep(500);
    }
    return null;
  }

  async function findGenerateButton() {
    for (let i = 0; i < 20; i++) {
      const buttons = Array.from(document.querySelectorAll('button'));
      const gen = buttons.find(b => {
        const t = (b.textContent || b.getAttribute('aria-label') || '').toLowerCase();
        return t.includes("generate") || t.includes("create") || t === "arrow_forward";
      });
      if (gen && !gen.disabled) return gen;
      await sleep(500);
    }
    return null;
  }

  async function selectMode(targetMode) {
    const buttons = Array.from(document.querySelectorAll('button, [role="tab"], [role="button"]'));
    const modeBtn = buttons.find(b => (b.textContent || '').trim().toLowerCase() === targetMode.toLowerCase());
    if (modeBtn) {
      modeBtn.click();
      await sleep(300);
    }
  }

  async function selectAspectRatio(ratio) {
    const buttons = Array.from(document.querySelectorAll('button, [role="button"]'));
    const btn = buttons.find(b => (b.textContent || '').includes(ratio));
    if (btn) {
      btn.click();
      await sleep(200);
    }
  }

  async function selectDuration(seconds) {
    const buttons = Array.from(document.querySelectorAll('button, [role="button"]'));
    const btn = buttons.find(b => (b.textContent || '').includes(`${seconds}s`));
    if (btn) {
      btn.click();
      await sleep(200);
    }
  }

  async function attachStartFrameImage(base64Data) {
    // Look for "+ Add start frame" or file input
    const fileInputs = document.querySelectorAll('input[type="file"]');
    if (fileInputs.length > 0) {
      const input = fileInputs[0];
      const byteCharacters = atob(base64Data);
      const byteNumbers = new Array(byteCharacters.length);
      for (let i = 0; i < byteCharacters.length; i++) {
        byteNumbers[i] = byteCharacters.charCodeAt(i);
      }
      const byteArray = new Uint8Array(byteNumbers);
      const blob = new Blob([byteArray], { type: "image/png" });
      const file = new File([blob], "start_frame.png", { type: "image/png" });

      const dataTransfer = new DataTransfer();
      dataTransfer.items.add(file);
      input.files = dataTransfer.files;
      input.dispatchEvent(new Event("change", { bubbles: true }));
      await sleep(1000);
    }
  }

  async function waitForGenerationCompletion(sceneNumber, type) {
    const startTime = Date.now();
    const timeoutMs = type === "video" ? 600000 : 180000; // 10 min for video, 3 min for image

    while (Date.now() - startTime < timeoutMs) {
      if (abortRequested) {
        return { isSuccess: false, error: "Generation stopped by user." };
      }

      // Check for error toast or policy warnings
      const errorEl = document.querySelector('.error-banner, [role="alert"], .toast-error');
      if (errorEl && errorEl.textContent) {
        return { isSuccess: false, error: errorEl.textContent.trim() };
      }

      // Check for completed asset (image or video tag with valid src)
      const mediaEls = document.querySelectorAll(type === "video" ? "video" : "img.generated-output, img[src*='blob:'], img[src*='googleusercontent']");
      if (mediaEls.length > 0) {
        const latest = mediaEls[mediaEls.length - 1];
        const src = latest.src || latest.currentSrc;
        if (src && !src.includes("placeholder") && !src.includes("loading")) {
          // Success!
          return {
            isSuccess: true,
            jobId: `flow_${sceneNumber}_${Date.now()}`,
            assetUrl: src
          };
        }
      }

      notifyProgress(sceneNumber, Math.min(95, 50 + Math.floor((Date.now() - startTime) / 10000) * 5), "Rendering in progress...");
      await sleep(3000);
    }

    return { isSuccess: false, error: "Timeout waiting for Google Flow generation." };
  }

  // --- Bridge Dispatch Notifications ---

  function notifyProgress(scene, progress, msg) {
    if (socket && socket.readyState === WebSocket.OPEN) {
      socket.send(JSON.stringify({
        type: "JOB_PROGRESS",
        sceneNumber: scene,
        progress: progress,
        message: msg
      }));
    }
  }

  function notifyCompleted(scene, jobId, assetUrl) {
    if (socket && socket.readyState === WebSocket.OPEN) {
      socket.send(JSON.stringify({
        type: "JOB_COMPLETED",
        sceneNumber: scene,
        jobId: jobId,
        assetUrl: assetUrl
      }));
    }
  }

  function notifyFailed(scene, error) {
    if (socket && socket.readyState === WebSocket.OPEN) {
      socket.send(JSON.stringify({
        type: "JOB_FAILED",
        sceneNumber: scene,
        error: error
      }));
    }
  }

  function sleep(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
  }

  // Start connection
  connectBridge();
})();
