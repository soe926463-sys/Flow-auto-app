"""
Test Bridge Protocol payload structure and validation.
"""
import unittest
import json

class TestBridgeProtocol(unittest.TestCase):
    def test_handshake_payload(self):
        payload = {
            "type": "HANDSHAKE",
            "client": "Lemur Browser (Android)",
            "credits": "500 credits available"
        }
        raw = json.dumps(payload)
        parsed = json.loads(raw)
        self.assertEqual(parsed["type"], "HANDSHAKE")
        self.assertEqual(parsed["client"], "Lemur Browser (Android)")

    def test_image_job_payload(self):
        payload = {
            "type": "GENERATE_IMAGE",
            "intentId": "test-uuid-1234",
            "sceneNumber": 1,
            "prompt": "Cinematic mountain sunrise",
            "model": "Nano Banana Pro",
            "aspectRatio": "16:9"
        }
        raw = json.dumps(payload)
        parsed = json.loads(raw)
        self.assertEqual(parsed["sceneNumber"], 1)
        self.assertEqual(parsed["model"], "Nano Banana Pro")

    def test_video_job_payload(self):
        payload = {
            "type": "GENERATE_VIDEO",
            "intentId": "test-uuid-5678",
            "sceneNumber": 1,
            "prompt": "Drone shot rising above clouds",
            "imageBase64": "iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mNk+M9QDwADhgGAWjR9awAAAABJRU5ErkJggg==",
            "model": "Veo 3.1 Lite",
            "duration": 5,
            "aspectRatio": "16:9"
        }
        raw = json.dumps(payload)
        parsed = json.loads(raw)
        self.assertEqual(parsed["duration"], 5)
        self.assertTrue(len(parsed["imageBase64"]) > 0)

if __name__ == "__main__":
    unittest.main()
