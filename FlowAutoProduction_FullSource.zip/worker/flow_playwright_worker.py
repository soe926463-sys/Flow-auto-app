"""
Playwright Chromium Worker for Google Flow.

Used as an alternative worker if external browser automation is preferred.
Preserves user session in persistent context (no credentials stored in code).
Connects to Flow Auto Production Android app via WebSocket bridge.
"""

import asyncio
import json
import os
import sys
from playwright.async_api import async_playwright

FLOW_URL = "https://flow.google.com/"
BRIDGE_WS_URL = os.environ.get("BRIDGE_WS_URL", "ws://127.0.0.1:28841/flow-bridge")
USER_DATA_DIR = os.path.expanduser("~/.flow_playwright_profile")

async def run_worker():
    print(f"Starting Playwright Worker for Google Flow...")
    print(f"Persistent User Data Dir: {USER_DATA_DIR}")

    async with async_playwright() as p:
        # Launch persistent context so user signs in once interactively
        context = await p.chromium.launch_persistent_context(
            user_data_dir=USER_DATA_DIR,
            headless=False,
            viewport={"width": 1280, "height": 800},
            args=["--disable-blink-features=AutomationControlled"]
        )

        page = await context.new_page()
        await page.goto(FLOW_URL)
        print("Flow page loaded. Please ensure you are logged into your Google Account.")

        # Listen for bridge commands or loop
        print("Worker active. Ready to process sequential generations.")

if __name__ == "__main__":
    try:
        asyncio.run(run_worker())
    except KeyboardInterrupt:
        print("Worker stopped.")
