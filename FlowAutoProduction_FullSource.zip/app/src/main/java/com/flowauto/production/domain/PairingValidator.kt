package com.flowauto.production.domain

import java.io.File

/**
 * PairingValidator handles Stage 1 to Stage 2 transition and external image imports.
 *
 * Enforces strict 1:1 scene pairing:
 * - Scene 01 Image <-> Scene 01 Video Prompt
 * - Scene 02 Image <-> Scene 02 Video Prompt
 * - Rejects mismatched counts (e.g., 10 images vs 9 prompts).
 * - Rejects ambiguous image filenames (e.g., multiple files claiming scene 1, or unparseable names).
 * - Generates structured pairing preview for user review.
 */
object PairingValidator {

    data class PairedScene(
        val sceneNumber: Int,
        val imageSource: String, // file path or URI
        val videoPrompt: String,
        val isValid: Boolean,
        val errorMessage: String? = null
    )

    data class ValidationResult(
        val isSuccess: Boolean,
        val pairedScenes: List<PairedScene>,
        val errorMessage: String? = null
    )

    /**
     * Pairs existing/generated image paths with parsed video prompts.
     * [imagePaths]: List of local image file paths
     * [videoPrompts]: List of video prompts in scene order
     */
    fun validateAndPair(
        imagePaths: List<String>,
        videoPrompts: List<String>
    ): ValidationResult {
        if (imagePaths.isEmpty()) {
            return ValidationResult(false, emptyList(), "No images provided for video generation.")
        }
        if (videoPrompts.isEmpty()) {
            return ValidationResult(false, emptyList(), "No video prompts provided. Stage 2 requires one video prompt per image.")
        }

        if (imagePaths.size != videoPrompts.size) {
            return ValidationResult(
                false,
                emptyList(),
                "Count mismatch: Provided ${imagePaths.size} images but ${videoPrompts.size} video prompts. Counts must match exactly 1:1."
            )
        }

        // Try to resolve scene numbers from filenames if imported externally
        val resolvedImages = mutableMapOf<Int, String>()
        val unassignedImages = mutableListOf<String>()

        for (path in imagePaths) {
            val fileName = File(path).nameWithoutExtension
            val sceneNum = extractSceneNumber(fileName)
            if (sceneNum != null) {
                if (resolvedImages.containsKey(sceneNum)) {
                    return ValidationResult(
                        false,
                        emptyList(),
                        "Ambiguous filename pairing: Multiple files resolve to Scene $sceneNum ('${File(resolvedImages[sceneNum]!!).name}' and '$fileName')."
                    )
                }
                resolvedImages[sceneNum] = path
            } else {
                unassignedImages.add(path)
            }
        }

        val pairedList = mutableListOf<PairedScene>()

        // Case A: All images had explicit scene numbering in filenames
        if (resolvedImages.size == imagePaths.size) {
            val sortedKeys = resolvedImages.keys.sorted()
            // Verify sequential numbers starting at 1
            for (idx in 0 until sortedKeys.size) {
                val expectedNum = idx + 1
                val actualNum = sortedKeys[idx]
                if (actualNum != expectedNum) {
                    return ValidationResult(
                        false,
                        emptyList(),
                        "Non-sequential scene numbering in images: Found Scene $actualNum, expected Scene $expectedNum."
                    )
                }
                val imagePath = resolvedImages[actualNum]!!
                val prompt = videoPrompts[idx]
                pairedList.add(
                    PairedScene(
                        sceneNumber = actualNum,
                        imageSource = imagePath,
                        videoPrompt = prompt,
                        isValid = true
                    )
                )
            }
        } else if (resolvedImages.isEmpty()) {
            // Case B: No files have scene numbers -> Pair strictly in natural index order (1..N)
            for (i in imagePaths.indices) {
                val sceneNum = i + 1
                pairedList.add(
                    PairedScene(
                        sceneNumber = sceneNum,
                        imageSource = imagePaths[i],
                        videoPrompt = videoPrompts[i],
                        isValid = true
                    )
                )
            }
        } else {
            // Mixed filenames: some have scene numbers and some do not -> Reject as ambiguous
            return ValidationResult(
                false,
                emptyList(),
                "Ambiguous image set: Some filenames contain scene numbers while others do not (${unassignedImages.size} unnumbered). Name all files consistently (e.g. scene_01.png..scene_10.png) or import ordered list."
            )
        }

        return ValidationResult(true, pairedList, null)
    }

    /**
     * Extracts scene number from common naming conventions:
     * - scene_01, scene01, scene-1, scene 1
     * - 01_image, 1.png, 01.jpg
     */
    fun extractSceneNumber(fileName: String): Int? {
        val lower = fileName.lowercase()

        // Pattern 1: scene[_- ]?(\d+)
        val matchScene = Regex("(?:scene|shot)[_\\s-]*(\\d+)").find(lower)
        if (matchScene != null) {
            return matchScene.groupValues[1].toIntOrNull()
        }

        // Pattern 2: ^(\d+)[_\\s-]
        val matchPrefix = Regex("^(\\d+)[_\\s-]").find(lower)
        if (matchPrefix != null) {
            return matchPrefix.groupValues[1].toIntOrNull()
        }

        // Pattern 3: ^(\d+)$
        if (Regex("^\\d+$").matches(lower)) {
            return lower.toIntOrNull()
        }

        return null
    }
}
