package com.flowauto.production.domain

/**
 * PromptParser parses raw pasted text or imported UTF-8 TXT files into numbered scenes (1..50).
 *
 * CRITICAL REQUIREMENTS:
 * - Preserves Burmese Unicode (U+1000..U+109F, U+AA60..U+AA7F) exactly as entered.
 * - Preserves dialogue quotes, internal whitespace, punctuation, and multi-line formatting.
 * - Never silently rewrites, transliterates, or alters prompt strings.
 * - Supports explicit custom separators (e.g., "---") and numbered scene headers.
 * - Enforces minimum 1 and maximum 50 scenes.
 */
object PromptParser {

    data class ParseResult(
        val prompts: List<String>,
        val error: String? = null
    )

    fun parse(rawInput: String, explicitSeparator: String? = null): ParseResult {
        if (rawInput.isBlank()) {
            return ParseResult(emptyList(), "Prompt input cannot be empty.")
        }

        val rawPrompts: List<String> = when {
            !explicitSeparator.isNullOrBlank() -> {
                // Split strictly by the user's explicit separator
                rawInput.split(explicitSeparator)
                    .map { cleanPrompt(it) }
                    .filter { it.isNotBlank() }
            }
            rawInput.contains("\n---\n") || rawInput.contains("\r\n---\r\n") -> {
                rawInput.split(Regex("\\r?\\n---\\r?\\n"))
                    .map { cleanPrompt(it) }
                    .filter { it.isNotBlank() }
            }
            Regex("(?m)^(?:Scene\\s*\\d+|\\d+[:.)])").containsMatchIn(rawInput) -> {
                // Numbered scene headers like "Scene 01:", "1.", "01)"
                val parts = rawInput.split(Regex("(?m)^(?=(?:Scene\\s*\\d+|\\d+[:.)]))"))
                parts.map { block ->
                    // Strip only the leading scene label marker, leave all prompt text, Burmese, dialogue intact
                    val stripped = block.replaceFirst(Regex("^(?:Scene\\s*\\d+[:.]?|\\d+[:.)])\\s*"), "")
                    cleanPrompt(stripped)
                }.filter { it.isNotBlank() }
            }
            rawInput.contains("\n\n") -> {
                // Double newline separator for distinct paragraphs
                rawInput.split(Regex("\\r?\\n\\s*\\r?\\n"))
                    .map { cleanPrompt(it) }
                    .filter { it.isNotBlank() }
            }
            else -> {
                // Single line per prompt fallback
                rawInput.lines()
                    .map { cleanPrompt(it) }
                    .filter { it.isNotBlank() }
            }
        }

        if (rawPrompts.isEmpty()) {
            return ParseResult(emptyList(), "No valid prompts found in input.")
        }

        if (rawPrompts.size > 50) {
            return ParseResult(
                emptyList(),
                "Too many prompts: Found ${rawPrompts.size} prompts. Maximum supported batch size is 50 scenes."
            )
        }

        return ParseResult(rawPrompts, null)
    }

    /**
     * Cleans outer boundary whitespace while strictly preserving internal Unicode, dialogue,
     * newlines, and indentation.
     */
    private fun cleanPrompt(text: String): String {
        return text.trim()
    }
}
