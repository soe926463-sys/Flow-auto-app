package com.flowauto.production.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.flowauto.production.data.SceneEntity
import com.flowauto.production.domain.PairingValidator
import com.flowauto.production.domain.PromptParser
import com.flowauto.production.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ReviewScreen(
    isConnected: Boolean,
    credits: String?,
    scenes: List<SceneEntity>,
    onStartVideos: (List<SceneEntity>) -> Unit,
    onNavigateBack: () -> Unit
) {
    var rawVideoPromptsText by remember { mutableStateOf("") }
    var explicitSeparator by remember { mutableStateOf("---") }
    var selectedVideoModel by remember { mutableStateOf("Veo 3.1 Lite") }
    var selectedDuration by remember { mutableStateOf(5) }
    var validationError by remember { mutableStateOf<String?>(null) }
    var pairedList by remember { mutableStateOf<List<PairingValidator.PairedScene>>(emptyList()) }

    var showApprovalDialog by remember { mutableStateOf(false) }
    var isSingleTestMode by remember { mutableStateOf(true) }
    var hasApprovedSingleTest by remember { mutableStateOf(false) }

    // Re-validate pairings when inputs change
    LaunchedEffect(rawVideoPromptsText, explicitSeparator, scenes) {
        if (rawVideoPromptsText.isNotBlank()) {
            val promptResult = PromptParser.parse(rawVideoPromptsText, explicitSeparator.ifBlank { null })
            if (promptResult.error != null) {
                validationError = promptResult.error
                pairedList = emptyList()
            } else {
                // Collect image paths (or dummy references for Stage 1 scenes)
                val imagePaths = scenes.map { it.generatedImagePath ?: "scene_${String.format("%02d", it.sceneNumber)}_placeholder.png" }
                val pairResult = PairingValidator.validateAndPair(imagePaths, promptResult.prompts)
                if (!pairResult.isSuccess) {
                    validationError = pairResult.errorMessage
                    pairedList = emptyList()
                } else {
                    validationError = null
                    pairedList = pairResult.pairedScenes
                }
            }
        } else {
            pairedList = emptyList()
            validationError = null
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Stage 2: Video Pairing & Review", fontWeight = FontWeight.Bold, fontSize = 18.sp) },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = FlowSurface)
            )
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Stage 2 Guidance
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = FlowSurfaceVariant),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Text("Stage 2 Workflow", fontWeight = FontWeight.Bold, color = FlowSecondary)
                        Spacer(Modifier.height(4.dp))
                        Text(
                            "1. Review Stage 1 images beside original prompts below.\n" +
                            "2. Paste 1 video prompt per image (strict 1:1 pairing).\n" +
                            "3. Credits check and explicit approval required before generation.",
                            fontSize = 12.sp,
                            color = FlowTextSecondary
                        )
                    }
                }
            }

            // Video Prompt Input Area
            item {
                OutlinedTextField(
                    value = rawVideoPromptsText,
                    onValueChange = { rawVideoPromptsText = it },
                    label = { Text("Enter Video Prompts (1 per image, strict 1:1)") },
                    placeholder = { Text("Scene 01 video prompt...\n---\nScene 02 video prompt...") },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(160.dp),
                    shape = RoundedCornerShape(12.dp)
                )
            }

            // Video Settings (Model & Duration)
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text("Video Model", fontSize = 12.sp, color = FlowTextSecondary)
                        Spacer(Modifier.height(4.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            FilterChip(
                                selected = selectedVideoModel == "Veo 3.1 Lite",
                                onClick = { selectedVideoModel = "Veo 3.1 Lite" },
                                label = { Text("Veo 3.1 Lite") }
                            )
                            FilterChip(
                                selected = selectedVideoModel == "Veo 2",
                                onClick = { selectedVideoModel = "Veo 2" },
                                label = { Text("Veo 2") }
                            )
                        }
                    }

                    Column(modifier = Modifier.weight(1f)) {
                        Text("Duration", fontSize = 12.sp, color = FlowTextSecondary)
                        Spacer(Modifier.height(4.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            FilterChip(
                                selected = selectedDuration == 5,
                                onClick = { selectedDuration = 5 },
                                label = { Text("5s") }
                            )
                            FilterChip(
                                selected = selectedDuration == 8,
                                onClick = { selectedDuration = 8 },
                                label = { Text("8s") }
                            )
                        }
                    }
                }
            }

            // Validation Error if any
            if (validationError != null) {
                item {
                    Text("Validation Error: $validationError", color = FlowError, fontSize = 13.sp)
                }
            }

            // Start Videos Trigger Button
            item {
                Button(
                    onClick = { showApprovalDialog = true },
                    enabled = pairedList.isNotEmpty() && validationError == null && isConnected,
                    modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.buttonColors(containerColor = FlowSecondary),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Icon(Icons.Default.Movie, contentDescription = null)
                    Spacer(Modifier.width(8.dp))
                    Text("START VIDEOS (${pairedList.size} Scenes)")
                }
            }

            // Pairing Preview List
            if (pairedList.isNotEmpty()) {
                item {
                    Text("1:1 Pairing Verification Preview", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                }

                items(pairedList) { pair ->
                    Card(
                        colors = CardDefaults.cardColors(containerColor = FlowSurface),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .border(1.dp, FlowSurfaceVariant, RoundedCornerShape(8.dp))
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(
                                    String.format("Scene %02d", pair.sceneNumber),
                                    fontWeight = FontWeight.Bold,
                                    color = FlowSecondary
                                )
                                Text("Matched 1:1", color = FlowSecondary, fontSize = 11.sp)
                            }
                            Spacer(Modifier.height(4.dp))
                            Text(
                                "Image: ${pair.imageSource}",
                                fontSize = 12.sp,
                                color = FlowTextSecondary
                            )
                            Spacer(Modifier.height(2.dp))
                            Text(
                                "Video Prompt: ${pair.videoPrompt}",
                                fontSize = 13.sp,
                                color = FlowTextPrimary
                            )
                        }
                    }
                }
            }

            item { Spacer(Modifier.height(24.dp)) }
        }
    }

    // Explicit Credit Approval Dialog
    if (showApprovalDialog) {
        AlertDialog(
            onDismissRequest = { showApprovalDialog = false },
            title = { Text("Approve Google Flow Credit Usage", fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Security & Credit Protocol:")
                    Text("• Current Account Balance: ${credits ?: "Unable to read from DOM"}")
                    Text("• Model: $selectedVideoModel ($selectedDuration seconds)")
                    Text("• Batch Mode: ${if (isSingleTestMode) "ONE single end-to-end test (Scene 01)" else "Full Batch (${pairedList.size} scenes)"}")
                    Text("• Estimated Cost: Variable per Google Flow subscription plan (displayed cost will be confirmed on Flow UI).")
                    Spacer(Modifier.height(8.dp))
                    Text(
                        "Do you explicitly authorize submitting this video generation to Google Flow?",
                        fontWeight = FontWeight.SemiBold,
                        color = FlowPrimary
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        showApprovalDialog = false
                        // Prepare updated scene entities with video parameters
                        val updatedScenes = pairedList.map { pair ->
                            val existing = scenes.find { it.sceneNumber == pair.sceneNumber }
                            (existing ?: SceneEntity(sceneNumber = pair.sceneNumber, imagePrompt = "")).copy(
                                videoPrompt = pair.videoPrompt,
                                videoModel = selectedVideoModel,
                                videoDuration = selectedDuration,
                                videoAspectRatio = "16:9"
                            )
                        }
                        if (isSingleTestMode) {
                            onStartVideos(listOf(updatedScenes.first()))
                            hasApprovedSingleTest = true
                            isSingleTestMode = false // Unlock full batch after single test
                        } else {
                            onStartVideos(updatedScenes)
                        }
                    }
                ) {
                    Text(if (isSingleTestMode) "Approve 1 Test Scene" else "Approve Full Batch")
                }
            },
            dismissButton = {
                OutlinedButton(onClick = { showApprovalDialog = false }) {
                    Text("Cancel")
                }
            }
        )
    }
}
