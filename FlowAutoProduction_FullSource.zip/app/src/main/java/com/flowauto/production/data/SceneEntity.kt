package com.flowauto.production.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "scenes")
data class SceneEntity(
    @PrimaryKey
    val sceneNumber: Int, // 1 to 50
    val imagePrompt: String,
    val imageModel: String = "Nano Banana Pro",
    val imageAspectRatio: String = "16:9",
    val generatedImagePath: String? = null,
    val imageJobId: String? = null,

    val videoPrompt: String? = null,
    val videoModel: String = "Veo 3.1 Lite",
    val videoDuration: Int = 5,
    val videoAspectRatio: String = "16:9",
    val generatedVideoPath: String? = null,
    val videoJobId: String? = null,

    val status: SceneStatus = SceneStatus.PENDING,
    val lastError: String? = null,
    val retryCount: Int = 0,
    val updatedAt: Long = System.currentTimeMillis()
)
