package com.flowauto.production.data

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface SceneDao {
    @Query("SELECT * FROM scenes ORDER BY sceneNumber ASC")
    fun getAllScenesFlow(): Flow<List<SceneEntity>>

    @Query("SELECT * FROM scenes ORDER BY sceneNumber ASC")
    suspend fun getAllScenes(): List<SceneEntity>

    @Query("SELECT * FROM scenes WHERE sceneNumber = :sceneNumber LIMIT 1")
    suspend fun getScene(sceneNumber: Int): SceneEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrUpdate(scene: SceneEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(scenes: List<SceneEntity>)

    @Query("UPDATE scenes SET status = :status, lastError = :error, updatedAt = :timestamp WHERE sceneNumber = :sceneNumber")
    suspend fun updateStatus(sceneNumber: Int, status: SceneStatus, error: String? = null, timestamp: Long = System.currentTimeMillis())

    @Query("UPDATE scenes SET generatedImagePath = :path, imageJobId = :jobId, status = :status, updatedAt = :timestamp WHERE sceneNumber = :sceneNumber")
    suspend fun updateImageOutput(sceneNumber: Int, path: String, jobId: String, status: SceneStatus = SceneStatus.COMPLETED, timestamp: Long = System.currentTimeMillis())

    @Query("UPDATE scenes SET generatedVideoPath = :path, videoJobId = :jobId, status = :status, updatedAt = :timestamp WHERE sceneNumber = :sceneNumber")
    suspend fun updateVideoOutput(sceneNumber: Int, path: String, jobId: String, status: SceneStatus = SceneStatus.COMPLETED, timestamp: Long = System.currentTimeMillis())

    @Query("DELETE FROM scenes")
    suspend fun clearAll()
}
