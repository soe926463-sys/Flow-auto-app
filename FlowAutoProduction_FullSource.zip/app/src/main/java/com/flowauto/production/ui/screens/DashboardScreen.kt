package com.flowauto.production.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.flowauto.production.data.SceneEntity
import com.flowauto.production.data.SceneStatus
import com.flowauto.production.domain.PromptParser
import com.flowauto.production.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DashboardScreen(
    isConnected: Boolean,
    connectionInfo: String?,
    credits: String?,
    scenes: List<SceneEntity>,
    onStartImages: (List<SceneEntity>) -> Unit,
    onNavigateToReview: () -> Unit
) {
    var rawPromptsText by remember { mutableStateOf("") }
    var explicitSeparator by remember { mutableStateOf("---") }
    var selectedModel by remember { mutableStateOf("Nano Banana Pro") }
    var selectedAspectRatio by remember { mutableStateOf("16:9") }
    var parseError by remember { mutableStateOf<String?>(null) }
    var parsedScenes by remember { mutableStateOf<List<SceneEntity>>(emptyList()) }

    // Parse whenever input changes
    LaunchedEffect(rawPromptsText, explicitSeparator, selectedModel, selectedAspectRatio) {
        if (rawPromptsText.isNotBlank()) {
            val res = PromptParser.parse(rawPromptsText, explicitSeparator.ifBlank { null })
            if (res.error != null) {
                parseError = res.error
                parsedScenes = emptyList()
            } else {
                parseError = null
                parsedScenes = res.prompts.mapIndexed { index, prompt ->
                    SceneEntity(
                        sceneNumber = index + 1,
                        imagePrompt = prompt,
                        imageModel = selectedModel,
                        imageAspectRatio = selectedAspectRatio
                    )
                }
            }
        } else {
            parsedScenes = emptyList()
            parseError = null
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text("Flow Auto Production", fontWeight = FontWeight.Bold, fontSize = 18.sp)
                        Text(
                            text = if (isConnected) "● Lemur: Connected" else "○ Lemur: Not Connected",
                            color = if (isConnected) FlowSecondary else FlowError,
                            fontSize = 12.sp
                        )
                    }
                },
                actions = {
                    Badge(containerColor = FlowSurfaceVariant) {
                        Text(
                            text = "Credits: ${credits ?: "Unknown"}",
                            color = FlowTextPrimary,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                            fontSize = 12.sp
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = FlowSurface)
            )
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Bridge Connection Warning Card
            if (!isConnected) {
                item {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = FlowError.copy(alpha = 0.15f)),
                        modifier = Modifier
                            .fillMaxWidth()
                            .border(1.dp, FlowError.copy(alpha = 0.5f), RoundedCornerShape(12.dp))
                    ) {
                        Row(modifier = Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Warning, contentDescription = null, tint = FlowError)
                            Spacer(Modifier.width(12.dp))
                            Column {
                                Text("Lemur Browser Not Connected", fontWeight = FontWeight.Bold, color = FlowError)
                                Text(
                                    "Open Lemur Browser on your phone, visit flow.google.com, and verify the Flow Bridge extension icon is green.",
                                    fontSize = 12.sp,
                                    color = FlowTextPrimary
                                )
                            }
                        }
                    }
                }
            }

            // Stage 1 Header
            item {
                Text(
                    "Stage 1: Generate Images (1–50 Prompts)",
                    fontWeight = FontWeight.Bold,
                    fontSize = 16.sp,
                    color = FlowPrimary
                )
            }

            // Input Prompts Box
            item {
                OutlinedTextField(
                    value = rawPromptsText,
                    onValueChange = { rawPromptsText = it },
                    label = { Text("Paste 1–50 Prompts (Burmese Unicode & Dialogue Preserved)") },
                    placeholder = { Text("Scene 1 prompt...\n---\nScene 2 prompt...") },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(180.dp),
                    shape = RoundedCornerShape(12.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = FlowPrimary,
                        unfocusedBorderColor = FlowSurfaceVariant
                    )
                )
            }

            // Separator Configuration
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    OutlinedTextField(
                        value = explicitSeparator,
                        onValueChange = { explicitSeparator = it },
                        label = { Text("Separator") },
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(8.dp)
                    )
                    OutlinedButton(
                        onClick = {
                            // Example quick fill for testing 10 scenes
                            rawPromptsText = (1..10).joinToString("\n---\n") { i ->
                                "Scene $i: မြန်မာ့ရိုးရာ ယဉ်ကျေးမှု visual style, cinematic lighting, shot $i"
                            }
                        },
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Text("Sample 10 (Burmese)")
                    }
                }
            }

            // Model & Settings Selectors
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text("Image Model", fontSize = 12.sp, color = FlowTextSecondary)
                        Spacer(Modifier.height(4.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            FilterChip(
                                selected = selectedModel == "Nano Banana Pro",
                                onClick = { selectedModel = "Nano Banana Pro" },
                                label = { Text("Nano Banana") }
                            )
                            FilterChip(
                                selected = selectedModel == "Imagen 3",
                                onClick = { selectedModel = "Imagen 3" },
                                label = { Text("Imagen 3") }
                            )
                        }
                    }

                    Column(modifier = Modifier.weight(1f)) {
                        Text("Aspect Ratio", fontSize = 12.sp, color = FlowTextSecondary)
                        Spacer(Modifier.height(4.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            FilterChip(
                                selected = selectedAspectRatio == "16:9",
                                onClick = { selectedAspectRatio = "16:9" },
                                label = { Text("16:9") }
                            )
                            FilterChip(
                                selected = selectedAspectRatio == "9:16",
                                onClick = { selectedAspectRatio = "9:16" },
                                label = { Text("9:16") }
                            )
                        }
                    }
                }
            }

            // Parsing error banner if any
            if (parseError != null) {
                item {
                    Text(parseError!!, color = FlowError, fontSize = 13.sp)
                }
            }

            // Action Buttons
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Button(
                        onClick = {
                            if (parsedScenes.isNotEmpty()) {
                                onStartImages(parsedScenes)
                            }
                        },
                        enabled = parsedScenes.isNotEmpty() && isConnected,
                        modifier = Modifier.weight(1f),
                        colors = ButtonDefaults.buttonColors(containerColor = FlowPrimary),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Icon(Icons.Default.PlayArrow, contentDescription = null)
                        Spacer(Modifier.width(8.dp))
                        Text("START IMAGES (${parsedScenes.size})")
                    }

                    OutlinedButton(
                        onClick = onNavigateToReview,
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Icon(Icons.Default.VideoLibrary, contentDescription = null)
                        Spacer(Modifier.width(8.dp))
                        Text("Stage 2 / Review")
                    }
                }
            }

            // Scene Preview List Header
            if (parsedScenes.isNotEmpty()) {
                item {
                    Text(
                        "Parsed Scenes Preview (${parsedScenes.size})",
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp
                    )
                }

                items(parsedScenes) { scene ->
                    Card(
                        colors = CardDefaults.cardColors(containerColor = FlowSurfaceVariant),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(
                                    String.format("Scene %02d", scene.sceneNumber),
                                    fontWeight = FontWeight.Bold,
                                    color = FlowPrimary
                                )
                                Text(
                                    "${scene.imageModel} • ${scene.imageAspectRatio}",
                                    fontSize = 11.sp,
                                    color = FlowTextSecondary
                                )
                            }
                            Spacer(Modifier.height(4.dp))
                            Text(
                                scene.imagePrompt,
                                fontSize = 13.sp,
                                maxLines = 3,
                                color = FlowTextPrimary
                            )
                        }
                    }
                }
            }

            item { Spacer(Modifier.height(24.dp)) }
        }
    }
}
