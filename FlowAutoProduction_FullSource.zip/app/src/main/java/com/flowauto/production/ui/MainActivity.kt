package com.flowauto.production.ui

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.runtime.*
import androidx.lifecycle.lifecycleScope
import com.flowauto.production.bridge.BridgeServer
import com.flowauto.production.data.AppDatabase
import com.flowauto.production.data.SceneEntity
import com.flowauto.production.engine.ForegroundProductionService
import com.flowauto.production.engine.ProductionEngine
import com.flowauto.production.ui.screens.DashboardScreen
import com.flowauto.production.ui.screens.ExecutionScreen
import com.flowauto.production.ui.screens.ReviewScreen
import com.flowauto.production.ui.theme.FlowAutoTheme
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {

    private lateinit var database: AppDatabase
    private lateinit var bridgeServer: BridgeServer
    private lateinit var productionEngine: ProductionEngine

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        database = AppDatabase.getInstance(this)
        bridgeServer = BridgeServer(port = 28841)
        productionEngine = ProductionEngine(database, bridgeServer, lifecycleScope)

        // Start local loopback bridge server
        bridgeServer.start()

        // Startup reconciliation for interrupted jobs
        lifecycleScope.launch {
            productionEngine.reconcileOnStartup()
        }

        setContent {
            FlowAutoTheme {
                var currentScreen by remember { mutableStateOf("dashboard") }

                val isConnected by bridgeServer.isConnected.collectAsState()
                val connectionInfo by bridgeServer.connectedClientInfo.collectAsState()
                val credits by bridgeServer.creditBalance.collectAsState()

                val scenes by database.sceneDao().getAllScenesFlow().collectAsState(initial = emptyList())
                val engineState by productionEngine.engineState.collectAsState()
                val activeScene by productionEngine.currentActiveScene.collectAsState()
                val statusMessage by productionEngine.statusMessage.collectAsState()

                when (currentScreen) {
                    "dashboard" -> {
                        DashboardScreen(
                            isConnected = isConnected,
                            connectionInfo = connectionInfo,
                            credits = credits,
                            scenes = scenes,
                            onStartImages = { scenesToStart ->
                                ForegroundProductionService.start(this)
                                productionEngine.startImages(scenesToStart)
                                currentScreen = "execution"
                            },
                            onNavigateToReview = {
                                currentScreen = "review"
                            }
                        )
                    }
                    "review" -> {
                        ReviewScreen(
                            isConnected = isConnected,
                            credits = credits,
                            scenes = scenes,
                            onStartVideos = { scenesToStart ->
                                ForegroundProductionService.start(this)
                                productionEngine.startVideos(scenesToStart)
                                currentScreen = "execution"
                            },
                            onNavigateBack = {
                                currentScreen = "dashboard"
                            }
                        )
                    }
                    "execution" -> {
                        ExecutionScreen(
                            engineState = engineState,
                            currentActiveScene = activeScene,
                            statusMessage = statusMessage,
                            scenes = scenes,
                            onPause = { productionEngine.pause() },
                            onResume = { productionEngine.resume() },
                            onStop = {
                                productionEngine.stop()
                                ForegroundProductionService.stop(this)
                            },
                            onRetryScene = { sceneNum ->
                                productionEngine.retryScene(sceneNum)
                            },
                            onNavigateBack = {
                                currentScreen = "dashboard"
                            }
                        )
                    }
                }
            }
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        bridgeServer.stop()
    }
}
