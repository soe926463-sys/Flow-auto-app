package com.flowauto.production.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "submission_intents")
data class SubmissionIntentEntity(
    @PrimaryKey
    val intentId: String,
    val sceneNumber: Int,
    val stage: Int, // 1 for Image, 2 for Video
    val prompt: String,
    val settingsSummary: String,
    val createdAt: Long = System.currentTimeMillis(),
    val dispatched: Boolean = false,
    val dispatchedAt: Long? = null,
    val remoteAckReceived: Boolean = false,
    val remoteJobId: String? = null,
    val resolved: Boolean = false
)
