package com.flowauto.production.bridge

import io.ktor.server.application.*
import io.ktor.server.engine.*
import io.ktor.server.netty.*
import io.ktor.server.routing.*
import io.ktor.server.websocket.*
import io.ktor.websocket.*
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import org.json.JSONObject
import java.time.Duration

/**
 * Embedded loopback WebSocket server on 127.0.0.1:28841.
 * Connects the Android app directly to the Lemur Browser extension running on the Galaxy S10.
 */
class BridgeServer(
    private val port: Int = 28841
) {
    private var server: NettyApplicationEngine? = null
    private var activeSession: WebSocketSession? = null

    private val _isConnected = MutableStateFlow(false)
    val isConnected: StateFlow<Boolean> = _isConnected.asStateFlow()

    private val _connectedClientInfo = MutableStateFlow<String?>("Not Connected")
    val connectedClientInfo: StateFlow<String?> = _connectedClientInfo.asStateFlow()

    private val _creditBalance = MutableStateFlow<String?>("Unknown (Open Flow in Lemur)")
    val creditBalance: StateFlow<String?> = _creditBalance.asStateFlow()

    // Listener for job updates from Lemur extension
    var onProgressReceived: ((sceneNumber: Int, progress: Int, message: String) -> Unit)? = null
    var onJobCompleted: ((sceneNumber: Int, jobId: String, assetUrl: String) -> Unit)? = null
    var onJobFailed: ((sceneNumber: Int, error: String) -> Unit)? = null

    fun start() {
        if (server != null) return

        server = embeddedServer(Netty, port = port, host = "127.0.0.1") {
            install(WebSockets) {
                pingPeriod = Duration.ofSeconds(5)
                timeout = Duration.ofSeconds(15)
                maxFrameSize = Long.MAX_VALUE
                masking = false
            }

            routing {
                webSocket("/flow-bridge") {
                    activeSession = this
                    _isConnected.value = true
                    _connectedClientInfo.value = "Connected to Lemur Browser (flow.google.com)"

                    try {
                        for (frame in incoming) {
                            if (frame is Frame.Text) {
                                val text = frame.readText()
                                handleIncomingMessage(text)
                            }
                        }
                    } catch (e: Exception) {
                        // Connection dropped
                    } finally {
                        activeSession = null
                        _isConnected.value = false
                        _connectedClientInfo.value = "Disconnected"
                    }
                }
            }
        }.start(wait = false)
    }

    fun stop() {
        server?.stop(1000, 2000)
        server = null
        _isConnected.value = false
        _connectedClientInfo.value = "Stopped"
    }

    private fun handleIncomingMessage(rawJson: String) {
        try {
            val json = JSONObject(rawJson)
            val type = json.optString("type")

            when (type) {
                "HANDSHAKE" -> {
                    val client = json.optString("client", "Lemur")
                    val credits = json.optString("credits", "Detected")
                    _creditBalance.value = credits
                    _connectedClientInfo.value = "Ready: $client ($credits)"
                }
                "CREDIT_UPDATE" -> {
                    val credits = json.optString("credits")
                    _creditBalance.value = credits
                }
                "JOB_PROGRESS" -> {
                    val scene = json.optInt("sceneNumber")
                    val prog = json.optInt("progress", 0)
                    val msg = json.optString("message", "")
                    onProgressReceived?.invoke(scene, prog, msg)
                }
                "JOB_COMPLETED" -> {
                    val scene = json.optInt("sceneNumber")
                    val jobId = json.optString("jobId", "job_${System.currentTimeMillis()}")
                    val assetUrl = json.optString("assetUrl", "")
                    onJobCompleted?.invoke(scene, jobId, assetUrl)
                }
                "JOB_FAILED" -> {
                    val scene = json.optInt("sceneNumber")
                    val error = json.optString("error", "Unknown error in Flow")
                    onJobFailed?.invoke(scene, error)
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    suspend fun sendImageJob(
        intentId: String,
        sceneNumber: Int,
        prompt: String,
        model: String,
        aspectRatio: String
    ): Boolean {
        val session = activeSession ?: return false
        val payload = JSONObject().apply {
            put("type", "GENERATE_IMAGE")
            put("intentId", intentId)
            put("sceneNumber", sceneNumber)
            put("prompt", prompt)
            put("model", model)
            put("aspectRatio", aspectRatio)
        }
        session.send(Frame.Text(payload.toString()))
        return true
    }

    suspend fun sendVideoJob(
        intentId: String,
        sceneNumber: Int,
        prompt: String,
        imageBase64: String?,
        model: String,
        duration: Int,
        aspectRatio: String
    ): Boolean {
        val session = activeSession ?: return false
        val payload = JSONObject().apply {
            put("type", "GENERATE_VIDEO")
            put("intentId", intentId)
            put("sceneNumber", sceneNumber)
            put("prompt", prompt)
            put("imageBase64", imageBase64 ?: "")
            put("model", model)
            put("duration", duration)
            put("aspectRatio", aspectRatio)
        }
        session.send(Frame.Text(payload.toString()))
        return true
    }

    suspend fun sendStop() {
        val session = activeSession ?: return
        val payload = JSONObject().apply {
            put("type", "STOP_EXECUTION")
        }
        session.send(Frame.Text(payload.toString()))
    }
}
