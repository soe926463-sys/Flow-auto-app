package com.flowauto.production.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val FlowDarkBackground = Color(0xFF121214)
val FlowSurface = Color(0xFF1E1E24)
val FlowSurfaceVariant = Color(0xFF282830)
val FlowPrimary = Color(0xFF3B82F6) // Electric Blue
val FlowPrimaryVariant = Color(0xFF1D4ED8)
val FlowSecondary = Color(0xFF10B981) // Emerald Green for success/ready
val FlowError = Color(0xFFEF4444)
val FlowWarning = Color(0xFFF59E0B)
val FlowTextPrimary = Color(0xFFF3F4F6)
val FlowTextSecondary = Color(0xFF9CA3AF)

private val DarkColorScheme = darkColorScheme(
    primary = FlowPrimary,
    secondary = FlowSecondary,
    background = FlowDarkBackground,
    surface = FlowSurface,
    surfaceVariant = FlowSurfaceVariant,
    error = FlowError,
    onPrimary = Color.White,
    onSecondary = Color.White,
    onBackground = FlowTextPrimary,
    onSurface = FlowTextPrimary
)

@Composable
fun FlowAutoTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = DarkColorScheme,
        content = content
    )
}
