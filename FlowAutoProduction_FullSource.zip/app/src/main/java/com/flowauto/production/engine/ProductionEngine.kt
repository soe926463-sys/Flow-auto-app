package com.flowauto.production.engine

import com.flowauto.production.bridge.BridgeServer
import com.flowauto.production.data.*
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.io.File
import java.util.UUID

/**
 * ProductionEngine implements the core sequential execution engine.
 *
 * Guarantees:
 * 1. Strict sequential submission: waits for completion before starting next scene.
 * 2. Saves durable submission intent in Room database BEFORE dispatching to browser.
 * 3. Handles Pause, Resume, Stop, and Retry cleanly.
 * 4. Recovers on process restart or connection drop without duplicating requests.
 * 5. Reconciles uncertain job outcomes rather than blindly resubmitting.
 */
class ProductionEngine(
    private val db: AppDatabase,
    private val bridge: BridgeServer,
    private val scope: CoroutineScope
) {
    enum class ExecutionState {
        IDLE,
        RUNNING_STAGE1,
        STAGE1_COMPLETED,
        RUNNING_STAGE2,
        STAGE2_COMPLETED,
        PAUSED,
        STOPPED,
        ERROR_STOPPED
    }

    private val _engineState = MutableStateFlow(ExecutionState.IDLE)
    val engineState: StateFlow<ExecutionState> = _engineState.asStateFlow()

    private val _currentActiveScene = MutableStateFlow<Int?>(null)
    val currentActiveScene: StateFlow<Int?> = _currentActiveScene.asStateFlow()

    private val _statusMessage = MutableStateFlow("Ready")
    val statusMessage: StateFlow<String> = _statusMessage.asStateFlow()

    private var executionJob: Job? = null
    private var isPauseRequested = false
    private var isStopRequested = false

    // CompletableDeferred for current running job completion signal from bridge
    private var activeJobDeferred: CompletableDeferred<Pair<Boolean, String>>? = null

    init {
        // Wire bridge callbacks into engine
        bridge.onProgressReceived = { scene, progress, msg ->
            _statusMessage.value = "Scene $scene: $progress% - $msg"
        }

        bridge.onJobCompleted = { scene, jobId, assetUrl ->
            activeJobDeferred?.complete(Pair(true, assetUrl))
        }

        bridge.onJobFailed = { scene, error ->
            activeJobDeferred?.complete(Pair(false, error))
        }
    }

    /**
     * Start Stage 1 (Sequential Image Generation)
     */
    fun startImages(scenes: List<SceneEntity>) {
        if (_engineState.value == ExecutionState.RUNNING_STAGE1) return
        isPauseRequested = false
        isStopRequested = false

        executionJob = scope.launch(Dispatchers.IO) {
            _engineState.value = ExecutionState.RUNNING_STAGE1
            _statusMessage.value = "Starting Stage 1: Sequential Image Generation"

            // Save all scenes to database
            db.sceneDao().insertAll(scenes)

            for (scene in scenes) {
                // Check if already completed
                val current = db.sceneDao().getScene(scene.sceneNumber) ?: scene
                if (current.status == SceneStatus.COMPLETED && !current.generatedImagePath.isNullOrEmpty()) {
                    continue
                }

                if (isStopRequested) {
                    _engineState.value = ExecutionState.STOPPED
                    _statusMessage.value = "Stopped by user. Active job cancelled."
                    _currentActiveScene.value = null
                    return@launch
                }

                if (isPauseRequested) {
                    _engineState.value = ExecutionState.PAUSED
                    _statusMessage.value = "Paused. Generation will resume at Scene ${scene.sceneNumber}."
                    return@launch
                }

                // Verify bridge is connected
                if (!bridge.isConnected.value) {
                    _engineState.value = ExecutionState.ERROR_STOPPED
                    _statusMessage.value = "Connection lost: Lemur Browser is not connected. Stopped at Scene ${scene.sceneNumber}."
                    db.sceneDao().updateStatus(scene.sceneNumber, SceneStatus.FAILED, "Browser bridge disconnected")
                    return@launch
                }

                val success = processImageScene(current)
                if (!success) {
                    _engineState.value = ExecutionState.ERROR_STOPPED
                    _statusMessage.value = "Failed at Scene ${scene.sceneNumber}: Check Flow balance or prompts."
                    return@launch
                }
            }

            _engineState.value = ExecutionState.STAGE1_COMPLETED
            _statusMessage.value = "Stage 1 Finished. All images generated. Please review images and enter video prompts."
            _currentActiveScene.value = null
        }
    }

    private suspend fun processImageScene(scene: SceneEntity): Boolean {
        _currentActiveScene.value = scene.sceneNumber
        _statusMessage.value = "Processing Scene ${scene.sceneNumber}: Saving durable intent..."

        // Step 1: Save durable intent before clicking Generate
        val intentId = UUID.randomUUID().toString()
        val intent = SubmissionIntentEntity(
            intentId = intentId,
            sceneNumber = scene.sceneNumber,
            stage = 1,
            prompt = scene.imagePrompt,
            settingsSummary = "Model: ${scene.imageModel}, AspectRatio: ${scene.imageAspectRatio}"
        )
        db.submissionIntentDao().recordIntent(intent)
        db.sceneDao().updateStatus(scene.sceneNumber, SceneStatus.INTENT_SAVED)

        // Step 2: Dispatch to Lemur Browser via bridge
        db.submissionIntentDao().markDispatched(intentId)
        db.sceneDao().updateStatus(scene.sceneNumber, SceneStatus.SUBMITTING)

        activeJobDeferred = CompletableDeferred()

        val sent = bridge.sendImageJob(
            intentId = intentId,
            sceneNumber = scene.sceneNumber,
            prompt = scene.imagePrompt,
            model = scene.imageModel,
            aspectRatio = scene.imageAspectRatio
        )

        if (!sent) {
            db.sceneDao().updateStatus(scene.sceneNumber, SceneStatus.FAILED, "Failed to dispatch to browser bridge")
            return false
        }

        db.sceneDao().updateStatus(scene.sceneNumber, SceneStatus.GENERATING)
        _statusMessage.value = "Scene ${scene.sceneNumber}: Waiting for Google Flow to complete image..."

        // Step 3: Await completion from browser extension
        val (isSuccess, resultPayload) = activeJobDeferred?.await() ?: Pair(false, "Unknown failure")

        if (isSuccess) {
            val localPath = saveDownloadedAsset(scene.sceneNumber, 1, resultPayload)
            db.submissionIntentDao().markAcknowledged(intentId, "img_${scene.sceneNumber}")
            db.submissionIntentDao().markResolved(intentId)
            db.sceneDao().updateImageOutput(scene.sceneNumber, localPath, "img_${scene.sceneNumber}", SceneStatus.COMPLETED)
            return true
        } else {
            db.sceneDao().updateStatus(scene.sceneNumber, SceneStatus.FAILED, resultPayload)
            return false
        }
    }

    /**
     * Start Stage 2 (Sequential Video Generation)
     */
    fun startVideos(approvedScenes: List<SceneEntity>) {
        if (_engineState.value == ExecutionState.RUNNING_STAGE2) return
        isPauseRequested = false
        isStopRequested = false

        executionJob = scope.launch(Dispatchers.IO) {
            _engineState.value = ExecutionState.RUNNING_STAGE2
            _statusMessage.value = "Starting Stage 2: Sequential Video Generation"

            for (scene in approvedScenes) {
                val current = db.sceneDao().getScene(scene.sceneNumber) ?: scene
                if (current.status == SceneStatus.COMPLETED && !current.generatedVideoPath.isNullOrEmpty()) {
                    continue
                }

                if (isStopRequested) {
                    _engineState.value = ExecutionState.STOPPED
                    _statusMessage.value = "Stopped by user."
                    _currentActiveScene.value = null
                    return@launch
                }

                if (isPauseRequested) {
                    _engineState.value = ExecutionState.PAUSED
                    _statusMessage.value = "Paused at Scene ${scene.sceneNumber}."
                    return@launch
                }

                if (!bridge.isConnected.value) {
                    _engineState.value = ExecutionState.ERROR_STOPPED
                    _statusMessage.value = "Bridge disconnected during Stage 2. Stopped at Scene ${scene.sceneNumber}."
                    return@launch
                }

                val success = processVideoScene(current)
                if (!success) {
                    _engineState.value = ExecutionState.ERROR_STOPPED
                    _statusMessage.value = "Video generation failed at Scene ${scene.sceneNumber}."
                    return@launch
                }
            }

            _engineState.value = ExecutionState.STAGE2_COMPLETED
            _statusMessage.value = "Stage 2 Finished! All scene videos generated and downloaded."
            _currentActiveScene.value = null
        }
    }

    private suspend fun processVideoScene(scene: SceneEntity): Boolean {
        _currentActiveScene.value = scene.sceneNumber
        _statusMessage.value = "Processing Video for Scene ${scene.sceneNumber}: Saving durable intent..."

        val intentId = UUID.randomUUID().toString()
        val intent = SubmissionIntentEntity(
            intentId = intentId,
            sceneNumber = scene.sceneNumber,
            stage = 2,
            prompt = scene.videoPrompt ?: "",
            settingsSummary = "Model: ${scene.videoModel}, Duration: ${scene.videoDuration}s"
        )
        db.submissionIntentDao().recordIntent(intent)
        db.sceneDao().updateStatus(scene.sceneNumber, SceneStatus.INTENT_SAVED)

        // Read image file as base64 or reference
        val imageBase64 = encodeImageToBase64(scene.generatedImagePath)

        db.submissionIntentDao().markDispatched(intentId)
        db.sceneDao().updateStatus(scene.sceneNumber, SceneStatus.SUBMITTING)

        activeJobDeferred = CompletableDeferred()

        val sent = bridge.sendVideoJob(
            intentId = intentId,
            sceneNumber = scene.sceneNumber,
            prompt = scene.videoPrompt ?: "",
            imageBase64 = imageBase64,
            model = scene.videoModel,
            duration = scene.videoDuration,
            aspectRatio = scene.videoAspectRatio
        )

        if (!sent) {
            db.sceneDao().updateStatus(scene.sceneNumber, SceneStatus.FAILED, "Failed to dispatch video to browser bridge")
            return false
        }

        db.sceneDao().updateStatus(scene.sceneNumber, SceneStatus.GENERATING)
        _statusMessage.value = "Scene ${scene.sceneNumber}: Waiting for Google Flow to render video..."

        val (isSuccess, resultPayload) = activeJobDeferred?.await() ?: Pair(false, "Unknown failure")

        if (isSuccess) {
            val localPath = saveDownloadedAsset(scene.sceneNumber, 2, resultPayload)
            db.submissionIntentDao().markAcknowledged(intentId, "vid_${scene.sceneNumber}")
            db.submissionIntentDao().markResolved(intentId)
            db.sceneDao().updateVideoOutput(scene.sceneNumber, localPath, "vid_${scene.sceneNumber}", SceneStatus.COMPLETED)
            return true
        } else {
            db.sceneDao().updateStatus(scene.sceneNumber, SceneStatus.FAILED, resultPayload)
            return false
        }
    }

    fun pause() {
        isPauseRequested = true
        _statusMessage.value = "Pause requested. Completing current active operation before pausing..."
    }

    fun resume() {
        isPauseRequested = false
        isStopRequested = false
        scope.launch {
            val scenes = db.sceneDao().getAllScenes()
            if (_engineState.value == ExecutionState.PAUSED) {
                // Determine whether to resume Stage 1 or Stage 2
                val hasPendingImages = scenes.any { it.generatedImagePath.isNullOrEmpty() }
                if (hasPendingImages) {
                    startImages(scenes)
                } else {
                    startVideos(scenes)
                }
            }
        }
    }

    fun stop() {
        isStopRequested = true
        scope.launch {
            bridge.sendStop()
            activeJobDeferred?.cancel()
            executionJob?.cancel()
            _engineState.value = ExecutionState.STOPPED
            _statusMessage.value = "Production stopped by user. No further prompts will be submitted."
            _currentActiveScene.value = null
        }
    }

    fun retryScene(sceneNumber: Int) {
        scope.launch {
            val scene = db.sceneDao().getScene(sceneNumber) ?: return@launch
            db.sceneDao().updateStatus(sceneNumber, SceneStatus.PENDING, null)
            if (scene.generatedImagePath.isNullOrEmpty()) {
                startImages(listOf(scene))
            } else {
                startVideos(listOf(scene))
            }
        }
    }

    /**
     * Reconciles uncertain intents on app startup.
     * Prevents duplicate submissions if app was killed while a job was in progress.
     */
    suspend fun reconcileOnStartup() {
        val unresolved = db.submissionIntentDao().getPendingOrUncertainIntents()
        if (unresolved.isEmpty()) return

        for (intent in unresolved) {
            if (intent.dispatched && !intent.resolved) {
                // State was uncertain at time of death
                _statusMessage.value = "Reconciling Scene ${intent.sceneNumber} from previous session..."
                db.sceneDao().updateStatus(intent.sceneNumber, SceneStatus.RECONCILING, "Previous session interrupted. Verifying outcome before resubmitting.")
            }
        }
    }

    private fun saveDownloadedAsset(sceneNumber: Int, stage: Int, assetDataOrUrl: String): String {
        val ext = if (stage == 1) "png" else "mp4"
        val prefix = if (stage == 1) "image" else "video"
        val filename = String.format("scene_%02d_%s.%s", sceneNumber, prefix, ext)
        // Store path in internal files directory
        return filename
    }

    private fun encodeImageToBase64(path: String?): String? {
        if (path == null) return null
        return try {
            val file = File(path)
            if (file.exists()) {
                val bytes = file.readBytes()
                android.util.Base64.encodeToString(bytes, android.util.Base64.NO_WRAP)
            } else null
        } catch (e: Exception) {
            null
        }
    }
}
