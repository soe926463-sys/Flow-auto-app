package com.flowauto.production.ui.screens

import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.flowauto.production.data.SceneEntity
import com.flowauto.production.data.SceneStatus
import com.flowauto.production.engine.ProductionEngine
import com.flowauto.production.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ExecutionScreen(
    engineState: ProductionEngine.ExecutionState,
    currentActiveScene: Int?,
    statusMessage: String,
    scenes: List<SceneEntity>,
    onPause: () -> Unit,
    onResume: () -> Unit,
    onStop: () -> Unit,
    onRetryScene: (Int) -> Unit,
    onNavigateBack: () -> Unit
) {
    val totalScenes = scenes.size
    val completedCount = scenes.count { it.status == SceneStatus.COMPLETED }
    val failedCount = scenes.count { it.status == SceneStatus.FAILED }
    val remainingCount = totalScenes - completedCount - failedCount

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Live Production Monitor", fontWeight = FontWeight.Bold, fontSize = 18.sp) },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = FlowSurface)
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Execution State Banner
            Card(
                colors = CardDefaults.cardColors(containerColor = FlowSurfaceVariant),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            "Status: ${engineState.name}",
                            fontWeight = FontWeight.Bold,
                            color = when (engineState) {
                                ProductionEngine.ExecutionState.RUNNING_STAGE1,
                                ProductionEngine.ExecutionState.RUNNING_STAGE2 -> FlowPrimary
                                ProductionEngine.ExecutionState.STAGE1_COMPLETED,
                                ProductionEngine.ExecutionState.STAGE2_COMPLETED -> FlowSecondary
                                ProductionEngine.ExecutionState.PAUSED -> FlowWarning
                                ProductionEngine.ExecutionState.ERROR_STOPPED,
                                ProductionEngine.ExecutionState.STOPPED -> FlowError
                                else -> FlowTextSecondary
                            }
                        )
                        if (currentActiveScene != null) {
                            Badge(containerColor = FlowPrimary) {
                                Text("Current: Scene $currentActiveScene", color = Color.White)
                            }
                        }
                    }
                    Spacer(Modifier.height(8.dp))
                    Text(statusMessage, fontSize = 13.sp, color = FlowTextPrimary)
                }
            }

            // Metric Counters (Completed, Remaining, Errors)
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                MetricCard("Completed", "$completedCount / $totalScenes", FlowSecondary, Modifier.weight(1f))
                MetricCard("Remaining", "$remainingCount", FlowTextSecondary, Modifier.weight(1f))
                MetricCard("Errors", "$failedCount", if (failedCount > 0) FlowError else FlowTextSecondary, Modifier.weight(1f))
            }

            // Controls (Pause, Resume, Stop)
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                when (engineState) {
                    ProductionEngine.ExecutionState.RUNNING_STAGE1,
                    ProductionEngine.ExecutionState.RUNNING_STAGE2 -> {
                        Button(
                            onClick = onPause,
                            modifier = Modifier.weight(1f),
                            colors = ButtonDefaults.buttonColors(containerColor = FlowWarning),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Icon(Icons.Default.Pause, contentDescription = null)
                            Spacer(Modifier.width(6.dp))
                            Text("Pause")
                        }
                        Button(
                            onClick = onStop,
                            modifier = Modifier.weight(1f),
                            colors = ButtonDefaults.buttonColors(containerColor = FlowError),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Icon(Icons.Default.Stop, contentDescription = null)
                            Spacer(Modifier.width(6.dp))
                            Text("Stop")
                        }
                    }
                    ProductionEngine.ExecutionState.PAUSED -> {
                        Button(
                            onClick = onResume,
                            modifier = Modifier.weight(1f),
                            colors = ButtonDefaults.buttonColors(containerColor = FlowSecondary),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Icon(Icons.Default.PlayArrow, contentDescription = null)
                            Spacer(Modifier.width(6.dp))
                            Text("Resume")
                        }
                        Button(
                            onClick = onStop,
                            modifier = Modifier.weight(1f),
                            colors = ButtonDefaults.buttonColors(containerColor = FlowError),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Icon(Icons.Default.Stop, contentDescription = null)
                            Spacer(Modifier.width(6.dp))
                            Text("Stop")
                        }
                    }
                    else -> {
                        // In idle, stopped, or error states
                    }
                }
            }

            // Itemized Scene List
            Text("Scenes Progression", fontWeight = FontWeight.Bold, fontSize = 14.sp)
            LazyColumn(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(scenes) { scene ->
                    Card(
                        colors = CardDefaults.cardColors(containerColor = FlowSurface),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .border(
                                width = if (scene.sceneNumber == currentActiveScene) 2.dp else 1.dp,
                                color = if (scene.sceneNumber == currentActiveScene) FlowPrimary else FlowSurfaceVariant,
                                shape = RoundedCornerShape(8.dp)
                            )
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    String.format("Scene %02d", scene.sceneNumber),
                                    fontWeight = FontWeight.Bold,
                                    color = if (scene.sceneNumber == currentActiveScene) FlowPrimary else FlowTextPrimary
                                )
                                Text(
                                    scene.status.name,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = when (scene.status) {
                                        SceneStatus.COMPLETED -> FlowSecondary
                                        SceneStatus.GENERATING, SceneStatus.SUBMITTING -> FlowPrimary
                                        SceneStatus.FAILED -> FlowError
                                        SceneStatus.PAUSED -> FlowWarning
                                        SceneStatus.RECONCILING -> FlowWarning
                                        else -> FlowTextSecondary
                                    }
                                )
                            }

                            if (scene.status == SceneStatus.FAILED) {
                                Spacer(Modifier.height(4.dp))
                                Text("Error: ${scene.lastError ?: "Failed"}", color = FlowError, fontSize = 12.sp)
                                Spacer(Modifier.height(4.dp))
                                OutlinedButton(
                                    onClick = { onRetryScene(scene.sceneNumber) },
                                    modifier = Modifier.height(32.dp),
                                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp)
                                ) {
                                    Icon(Icons.Default.Refresh, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(Modifier.width(4.dp))
                                    Text("Retry Scene", fontSize = 12.sp)
                                }
                            }

                            if (!scene.generatedImagePath.isNullOrEmpty()) {
                                Spacer(Modifier.height(4.dp))
                                Text("Image Output: ${scene.generatedImagePath}", fontSize = 11.sp, color = FlowSecondary)
                            }

                            if (!scene.generatedVideoPath.isNullOrEmpty()) {
                                Spacer(Modifier.height(2.dp))
                                Text("Video Output: ${scene.generatedVideoPath}", fontSize = 11.sp, color = FlowSecondary)
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun MetricCard(label: String, value: String, color: Color, modifier: Modifier = Modifier) {
    Card(
        colors = CardDefaults.cardColors(containerColor = FlowSurfaceVariant),
        shape = RoundedCornerShape(8.dp),
        modifier = modifier
    ) {
        Column(
            modifier = Modifier.padding(12.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(label, fontSize = 11.sp, color = FlowTextSecondary)
            Spacer(Modifier.height(4.dp))
            Text(value, fontSize = 16.sp, fontWeight = FontWeight.Bold, color = color)
        }
    }
}
