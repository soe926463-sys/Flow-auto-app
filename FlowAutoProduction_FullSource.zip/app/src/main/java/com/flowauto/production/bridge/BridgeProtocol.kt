package com.flowauto.production.bridge

import kotlinx.serialization.Serializable

@Serializable
sealed class BridgeMessage {
    @Serializable
    data class Handshake(
        val client: String,
        val pageUrl: String,
        val creditBalance: String? = null
    )

    @Serializable
    data class CreditInfo(
        val creditBalance: String,
        val estimatedJobCost: String? = null
    )

    @Serializable
    data class DispatchImageJob(
        val intentId: String,
        val sceneNumber: Int,
        val prompt: String,
        val model: String,
        val aspectRatio: String
    )

    @Serializable
    data class DispatchVideoJob(
        val intentId: String,
        val sceneNumber: Int,
        val prompt: String,
        val imageBase64: String?,
        val imageUrl: String?,
        val model: String,
        val duration: Int,
        val aspectRatio: String
    )

    @Serializable
    data class JobProgress(
        val intentId: String,
        val sceneNumber: Int,
        val status: String,
        val remoteJobId: String? = null,
        val progressPercent: Int = 0,
        val message: String? = null
    )

    @Serializable
    data class JobResult(
        val intentId: String,
        val sceneNumber: Int,
        val isSuccess: Boolean,
        val remoteJobId: String? = null,
        val assetUrl: String? = null,
        val assetBase64: String? = null,
        val errorMessage: String? = null
    )

    @Serializable
    data class ReconcileQuery(
        val pendingIntentIds: List<String>
    )

    @Serializable
    data class ReconcileResponse(
        val reconciledJobs: Map<String, String> // intentId -> status (e.g. "IN_PROGRESS", "COMPLETED", "NOT_FOUND")
    )
}
