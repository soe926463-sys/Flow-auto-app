package com.flowauto.production.data

enum class SceneStatus {
    PENDING,
    INTENT_SAVED,
    SUBMITTING,
    GENERATING,
    COMPLETED,
    FAILED,
    PAUSED,
    RECONCILING
}
