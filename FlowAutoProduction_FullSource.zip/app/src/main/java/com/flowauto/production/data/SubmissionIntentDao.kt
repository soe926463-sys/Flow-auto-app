package com.flowauto.production.data

import androidx.room.*

@Dao
interface SubmissionIntentDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun recordIntent(intent: SubmissionIntentEntity)

    @Query("SELECT * FROM submission_intents WHERE resolved = 0 ORDER BY createdAt ASC")
    suspend fun getPendingOrUncertainIntents(): List<SubmissionIntentEntity>

    @Query("UPDATE submission_intents SET dispatched = 1, dispatchedAt = :timestamp WHERE intentId = :intentId")
    suspend fun markDispatched(intentId: String, timestamp: Long = System.currentTimeMillis())

    @Query("UPDATE submission_intents SET remoteAckReceived = 1, remoteJobId = :jobId WHERE intentId = :intentId")
    suspend fun markAcknowledged(intentId: String, jobId: String)

    @Query("UPDATE submission_intents SET resolved = 1 WHERE intentId = :intentId")
    suspend fun markResolved(intentId: String)

    @Query("SELECT * FROM submission_intents WHERE sceneNumber = :sceneNumber AND stage = :stage ORDER BY createdAt DESC LIMIT 1")
    suspend fun getLatestIntentForScene(sceneNumber: Int, stage: Int): SubmissionIntentEntity?
}
